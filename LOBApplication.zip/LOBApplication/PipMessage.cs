﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LOBApplication
{
    public class PipMessage
    {
        public string PipId;
        public string PipCode;
        public string Source;
        public string Destination;
        public string PipVer;
        public string XmlContent;
    }
}
